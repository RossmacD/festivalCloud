# festivalCloud-scenario-1
This is the web application in scenario 1 of CloudAD CA2

## Local installation:

- Clone or download this repository
- Put files in htdocs (using XAMPP)
- Import database using sql file in the sql folder
- Edit the connection details in classes/Connection.php
